 const API = "http://localhost:5000/api";



// ADD TO CART
function addToCart(name, price) {

  let cart =
    JSON.parse(localStorage.getItem("cart")) || [];

  price = Number(price);

  const existingItem =
    cart.find(item => item.name === name);

  if (existingItem) {

    existingItem.quantity += 1;

  } else {

    cart.push({
      name: name,
      price: price,
      quantity: 1
    });
  }

  localStorage.setItem(
    "cart",
    JSON.stringify(cart)
  );

  alert("Item Added To Cart");
}



// DISPLAY CART
function displayCart() {

  const cartItems =
    document.getElementById("cartItems");

  const totalElement =
    document.getElementById("total");

  if (!cartItems || !totalElement) return;

  let cart =
    JSON.parse(localStorage.getItem("cart")) || [];

  let total = 0;

  cartItems.innerHTML = "";

  if (cart.length === 0) {

    cartItems.innerHTML = `
      <h4 class="text-center">
        Cart is Empty
      </h4>
    `;

    totalElement.innerText =
      "Total: ₹0";

    return;
  }

  cart.forEach((item) => {

    const itemTotal =
      item.price * item.quantity;

    total += itemTotal;

    cartItems.innerHTML += `

      <div class="card p-3 mb-3 shadow-sm border-0">

        <div class="d-flex justify-content-between align-items-center">

          <div>

            <h5>${item.name}</h5>

            <p class="mb-1">
              Quantity: ${item.quantity}
            </p>

            <p>
              Price: ₹${item.price}
            </p>

          </div>

          <h5>
            ₹${itemTotal}
          </h5>

        </div>

      </div>
    `;
  });

  totalElement.innerText =
    `Total: ₹${total}`;
}



// REGISTER
async function register() {

  const name =
    document.getElementById("name").value;

  const email =
    document.getElementById("regEmail").value;

  const password =
    document.getElementById("regPassword").value;


  // VALIDATION

  if (
    name === "" ||
    email === "" ||
    password === ""
  ) {

    alert("Please fill all fields");

    return;
  }

  if (!email.includes("@")) {

    alert("Enter valid email");

    return;
  }

  if (password.length < 6) {

    alert(
      "Password must be minimum 6 characters"
    );

    return;
  }


  try {

    const response = await fetch(
      `${API}/auth/register`,
      {
        method: "POST",

        headers: {
          "Content-Type":
            "application/json"
        },

        body: JSON.stringify({
          name,
          email,
          password
        })
      }
    );

    const data =
      await response.json();

    alert(data.message);

    window.location.href =
      "login.html";

  } catch (error) {

    alert("Server Error");
  }
}



// LOGIN
async function login() {

  const email =
    document.getElementById("email").value;

  const password =
    document.getElementById("password").value;


  // VALIDATION

  if (
    email === "" ||
    password === ""
  ) {

    alert("Please fill all fields");

    return;
  }

  if (!email.includes("@")) {

    alert("Enter valid email");

    return;
  }


  try {

    const response = await fetch(
      `${API}/auth/login`,
      {
        method: "POST",

        headers: {
          "Content-Type":
            "application/json"
        },

        body: JSON.stringify({
          email,
          password
        })
      }
    );

    const data =
      await response.json();

    if (data.token) {

      localStorage.setItem(
        "token",
        data.token
      );

      alert("Login Successful");

      window.location.href =
        "index.html";

    } else {

      alert(data.message);
    }

  } catch (error) {

    alert("Server Error");
  }
}
function clearCart() {

  localStorage.removeItem("cart");

  location.reload();
}